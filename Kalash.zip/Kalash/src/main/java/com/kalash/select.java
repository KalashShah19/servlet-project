package com.kalash;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

/**
 * Servlet implementation class select
 */
public class select extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public select() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<html><body>");
		 try {
			  
            // Initialize the database
            Connection con = db.initializeDatabase();
			java.sql.Statement stmt =  con.createStatement();
	        String sql;
	        sql = "SELECT * FROM Employees";
	        ResultSet rs = stmt.executeQuery(sql);
	        
	        // Extract data from result set
	        while(rs.next()){
	           //Retrieve by column name
	           String name = rs.getString("name");
	           String email = rs.getString("email");
	
	           //Display values
	           out.println("Name : " + name + "<br>");
	           out.println(", Email : " + email + "<br>");
	        }
	        out.println("</body></html>");
	
	        // Clean-up environment
	        rs.close();
	        stmt.close();
	        con.close();
		 }
		 catch (Exception e) {
	            e.printStackTrace();
	        }
		 
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
