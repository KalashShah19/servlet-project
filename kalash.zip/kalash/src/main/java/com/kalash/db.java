package com.kalash;
import java.sql.*;

public class db {
	public static Connection init() throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost/db", "root", "root");
		return con;
	}
}
